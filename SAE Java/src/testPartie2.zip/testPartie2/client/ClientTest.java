/**
 * 
 */
package client;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author lulub
 *
 */
class ClientTest {

	/**
	 * Test method for {@link client.Client#Client(java.lang.String, java.lang.String, int)}.
	 */
	@Test
	void testClientStringStringInt() {
		//GIVEN
		
		
		//WHEN
		Client client1 = new ClientEntreprise("broda", "marcq", 10,"oue");
		
		//THEN
	}

	/**
	 * Test method for {@link client.Client#Client()}.
	 */
	@Test
	void testClient() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#getPointsFidelite()}.
	 */
	@Test
	void testGetPointsFidelite() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#setPointsFidelite(int)}.
	 */
	@Test
	void testSetPointsFidelite() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#getNom()}.
	 */
	@Test
	void testGetNom() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#setNom(java.lang.String)}.
	 */
	@Test
	void testSetNom() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#getAdresse()}.
	 */
	@Test
	void testGetAdresse() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#setAdresse(java.lang.String)}.
	 */
	@Test
	void testSetAdresse() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#getReference()}.
	 */
	@Test
	void testGetReference() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#getRistourne()}.
	 */
	@Test
	void testGetRistourne() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#saisirInfos()}.
	 */
	@Test
	void testSaisirInfos() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#equals(java.lang.Object)}.
	 */
	@Test
	void testEqualsObject() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#toString()}.
	 */
	@Test
	void testToString() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#afficherTabClients(client.Client[])}.
	 */
	@Test
	void testAfficherTabClients() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.Client#trierTabClients(client.Client[])}.
	 */
	@Test
	void testTrierTabClients() {
		fail("Not yet implemented");
	}

}
