/**
 * 
 */
package client;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * @author lulub
 *
 */
class CarnetsClients {

	/**
	 * Test method for {@link client.CarnetClients#CarnetClients(java.lang.String)}.
	 */
	@Test
	void testCarnetClients() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#getNom()}.
	 */
	@Test
	void testGetNom() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#setNom(java.lang.String)}.
	 */
	@Test
	void testSetNom() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#getNbClients()}.
	 */
	@Test
	void testGetNbClients() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#estPlein()}.
	 */
	@Test
	void testEstPlein() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#estVide()}.
	 */
	@Test
	void testEstVide() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#ajouterClient(client.Client)}.
	 */
	@Test
	void testAjouterClient() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#rechercherClientParReference(int)}.
	 */
	@Test
	void testRechercherClientParReference() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#supprimerClient(client.Client)}.
	 */
	@Test
	void testSupprimerClient() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#clientsEntrepriseDansCarnet()}.
	 */
	@Test
	void testClientsEntrepriseDansCarnet() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#clientsParticulierDansCarnet()}.
	 */
	@Test
	void testClientsParticulierDansCarnet() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#clientsDansCarnet()}.
	 */
	@Test
	void testClientsDansCarnet() {
		fail("Not yet implemented");
	}

	/**
	 * Test method for {@link client.CarnetClients#rechercherClientsParMotCle(java.lang.String)}.
	 */
	@Test
	void testRechercherClientsParMotCle() {
		fail("Not yet implemented");
	}

}
